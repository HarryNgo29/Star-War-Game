/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package binhchingoproject12;

public class FightingGameTester {
    
  /**
  * @param args the command line arguments
  */
  public static void main(String[] args){
      
   //======================================================================
   // INITIALIZE
   //======================================================================  
   StarWarsCharacter Asaji = new StarWarsCharacter("Asajj", "Ventress", 30, "F", new Force(85,"Dark"), "I don't fear you, Jedi!");
   StarWarsCharacter Bariss = new StarWarsCharacter("Bariss", "Offee", 30, "F", new Force(85,"Light"), "Minimize expectations to avoid being disappointed!");
   StarWarsCharacter Darth = new StarWarsCharacter("Darth", "Vader", 42, "M", new Force(100,"Dark"), "I find your lack of faith disturbing!");
   StarWarsCharacter Emperor = new StarWarsCharacter("Emperor", "Palpatine", 82, "M", new Force(97,"Dark"), "Power! Unlimited Power!");
   StarWarsCharacter Kylo = new StarWarsCharacter("Kylo", "Ren", 20, "M", new Force(95,"Dark"), "Blast That Piece Of Junk Out Of The Sky!");
   StarWarsCharacter Luke = new StarWarsCharacter("Luke", "Skywalker", 19, "M", new Force(97,"Light"), "You want the impossible!");
   StarWarsCharacter ObiWan = new StarWarsCharacter("Obi Wan", "Kenobi", 57, "M", new Force(85,"Light"), "If you strike me down, I shall become more powerful than you can possibly imagine!");
   StarWarsCharacter Princess = new StarWarsCharacter("Princess", "Leia", 19, "F", new Force(85,"Light"), "We have everything we need!");
   StarWarsCharacter Rey = new StarWarsCharacter("Rey", "", 20, "F", new Force(96,"Light"), "Rey Skywalker!");
   StarWarsCharacter Storm1 = new StarWarsCharacter("Storm", "Trooper", 25, "M", new Force(1,"Dark"), "I wanna retire already!");
   StarWarsCharacter Storm2 = new StarWarsCharacter("Storm2", "Trooper", 25, "M", new Force(1,"Dark"), "Kill  you kill you!");
   StarWarsCharacter Storm3 = new StarWarsCharacter("Storm3", "Trooper", 25, "M", new Force(1,"Dark"), "I still did not show you my true ability!");
   StarWarsCharacter Storm4 = new StarWarsCharacter("Storm4", "Trooper", 25, "M", new Force(1,"Dark"), "He actully showed!");
   StarWarsCharacter Storm5 = new StarWarsCharacter("Storm5", "Trooper", 25, "M", new Force(1,"Dark"), "Why I am here!");
   StarWarsCharacter Yoda = new StarWarsCharacter("Yoda", "", 896, "M", new Force(99,"Light"), "Fear is the path to the dark side. Fear leads to anger. Anger leads to hate. Hate leads to suffering!");   
   
   System.out.println("________________SIMULATION_STARTS________________");
   System.out.println("_____________________Fights______________________");
   StarWarsCharacter.Fight(Rey, Asaji);
   StarWarsCharacter.Fight(Darth, Bariss);
   StarWarsCharacter.Fight(Emperor, Luke);
   StarWarsCharacter.Fight(ObiWan, Princess);
   StarWarsCharacter.Fight(Rey, Yoda);
   StarWarsCharacter.Fight(Kylo, Storm1);
   StarWarsCharacter.Fight(Yoda, Darth);
   System.out.println("_________________________________________________");

   
   System.out.println("____________________Abilities____________________");
   Force.Move(Yoda, "1000 soldiers");
   Force.Move(Storm1, "1 rock");
   Force.Influence(Darth, "1000 soldiers");
   Force.Influence(Storm2, "1 soldier");
   System.out.println("_________________________________________________");

   System.out.println("____________________Chattings____________________");
   StarWarsCharacter.Taunt(Storm1.GetTauntPhrase(), Storm1);
   StarWarsCharacter.Taunt(Storm2.GetTauntPhrase(), Storm2);
   StarWarsCharacter.Taunt(Storm3.GetTauntPhrase(), Storm3);
   StarWarsCharacter.Taunt(Storm4.GetTauntPhrase(), Storm4);
   StarWarsCharacter.Taunt(Storm5.GetTauntPhrase(), Storm5);
   System.out.println("_________________________________________________");
  }    
  
}
