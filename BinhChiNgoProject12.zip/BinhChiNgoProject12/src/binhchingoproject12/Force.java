package binhchingoproject12;

public class Force {
  
  //==========================================================================
  // PROPERTIES
  //==========================================================================
  
  //Strength
  protected int strength = 0;
  public int GetStrength() { return strength; }
  public void SetStrength( int power ) { strength = power; }
  
  //Side
  private String side = " ";
  public String GetSide() { return side; }
  public void SetSide( String side ) { this.side = side; }
  
  //==========================================================================
  // CONSTRUCTORS
  //==========================================================================
  
  /**
  * Constructor with a known strength and side
  * @param Strength and Side The Strength and Side of the Force
  */
  public Force ( int strength, String side ){
   SetStrength( strength );
   SetSide( side );
  }
  
  //==========================================================================
  // METHODS
  //==========================================================================
  
  //To pretend they are using telekinetic power
  public static void Influence ( StarWarsCharacter a, String target ){
      
    if(a.GetForce().GetStrength() >= 60){
     System.out.println(a.GetFirstName() + " ensures " + target + " there aren't the droids they're looking for. ");
    }
    else{
      System.out.println(a.GetFirstName() + " fails to influence " + target + ".");
    } 
    
  }
  
  //To pretend that they are moving
  public static void Move ( StarWarsCharacter a, String target ){
            
    if(a.GetForce().GetStrength() >= 60){
     System.out.println(a.GetFirstName() + " flings " + target + " across the room! ");
    }
    else{
      System.out.println(target + " is unmoved by " + a.GetFirstName() + ".");
    } 
    
  }
  
}
