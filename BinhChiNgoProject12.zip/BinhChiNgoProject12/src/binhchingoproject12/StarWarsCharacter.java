package binhchingoproject12;

public class StarWarsCharacter {
    
  //==========================================================================
  // PROPERTIES
  //==========================================================================
  
  //FirstName    
  protected String firstName = " ";
  public String GetFirstName() { return firstName; }
  public void SetFirstName( String name) { firstName = name;}

  //LastName
  protected String lastName; 
  public String GetLastName() { return lastName; }
  public void SetLastName( String name ) { lastName = name; }

  //Age
  protected int age = 0;
  public int GetAge() { return age; }
  public void SetAge (int years) { age = years; }

  //Gender
  protected String gender;
  public String GetGender() { return gender; }
  public void SetGender( String sex ) { gender = sex; }

  //Force
  protected Force force;
  public Force GetForce() { return force; }
  public void SetForce( Force force ) { this.force = force; }
  
  //TauntPhras
  protected String tauntPhrase;
  public String GetTauntPhrase() { return tauntPhrase; }
  public void SetTauntPhrase( String tauntPhrase ) { this.tauntPhrase = tauntPhrase; }

  //==========================================================================
  // CONSTRUCTORS
  //==========================================================================
  
  /**
  * Default Constructor
  */
  public StarWarsCharacter() { 

  } 

  /**
  * Constructor with a known firstName and lastName
  * @param Name The Name of the StarWarsCharacter
  */
  public StarWarsCharacter(String firstName, String lastName){
   SetFirstName( firstName );  
   SetLastName( lastName );  
  }
  
  /**
  * Constructor with a known firstName, lastName, and force
  * @param Name and Force The Name and Force of the StarWarsCharacter
  */
  public StarWarsCharacter (String firstName, String lastName, Force force){
   SetFirstName( firstName );  
   SetLastName( lastName );  
   SetForce( force );
  }
  
  /**
  * Constructor with a known firstName, lastName, age, gender, force, and tauntPhrase
  * @param Full The Full of the StarWarsCharacter
  */
  public StarWarsCharacter (String firstName, String lastName, int age, String gender, Force force, String tauntPhrase){
   SetFirstName( firstName );  
   SetLastName( lastName );  
   SetAge ( age );
   SetGender( gender ); 
   SetForce( force );
   SetTauntPhrase( tauntPhrase );
  }
  
  //==========================================================================
  // METHODS
  //==========================================================================
  
  //To print their phrase during a fight
  public static String Taunt(String tauntPhrase, StarWarsCharacter a){
      
   String output = a.GetFirstName() + " says: " + a.GetTauntPhrase();
   System.out.println(output);
   
   return output;   
  }
  
  //To make them fight by comparing side and strength
  public static void Fight( StarWarsCharacter a, StarWarsCharacter b ){
      
      if (a.GetForce().GetSide() != b.GetForce().GetSide()){
          
          if(a.GetForce().GetStrength() > b.GetForce().GetStrength()){
            System.out.println(a.GetFirstName() + " fights " + b.GetFirstName() + " and " + 
                               a.GetFirstName() + " wins! " + a.GetFirstName() + " gloats: " + a.GetTauntPhrase());        
          }
          else if(a.GetForce().GetStrength() < b.GetForce().GetStrength()){
            System.out.println(a.GetFirstName() + " fights " + b.GetFirstName() + " and " + 
                               b.GetFirstName() + " wins! " + b.GetFirstName() + " gloats: " + b.GetTauntPhrase());          }
          else{
            System.out.println(a.GetFirstName() + " and " + b.GetFirstName() + " have same strength so this match draws. ");   
          }
      }
          
      if (a.GetForce().GetSide() == b.GetForce().GetSide()){
           
          if(a.GetForce().GetStrength() > b.GetForce().GetStrength()){
            System.out.println(a.GetFirstName() + " is stronger in the " + a.GetForce().GetSide() + " side of "
                               + " the force than " + b.GetFirstName() + ".");
          }
          else if(a.GetForce().GetStrength() < b.GetForce().GetStrength()){
            System.out.println(b.GetFirstName() + " is stronger in the " + b.GetForce().GetSide() + " side of "
                               + " the force than " + a.GetFirstName() + ".");
          }
          else{
            System.out.println(a.GetFirstName() + " and " + b.GetFirstName() + " have same strength so this match draws. ");   
          }
      }
      
  }
    
}
