import binhchingoproject12.Force;
import binhchingoproject12.StarWarsCharacter;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author binhn
 */
public class StarWarsCharacterTest {

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private final PrintStream originalErr = System.err;

    @Before
    public void setUpStreams() {
     System.setOut(new PrintStream(outContent));
     System.setErr(new PrintStream(errContent));
    }

    @After
    public void restoreStreams() {
     System.setOut(originalOut);
     System.setErr(originalErr);
    }
    
    public StarWarsCharacterTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of Taunt method, of class StarWarsCharacter.
     */
    @Test
    public void testTaunt_CharacterSays_TauntPrintedOut() {
      StarWarsCharacter Yoda = new StarWarsCharacter("Yoda", "", 896, "M", new Force(99,"Light"), "Fear is the path to the dark side. Fear leads to anger. Anger leads to hate. Hate leads to suffering!");   
      String result = "Yoda says: Fear is the path to the dark side. Fear leads to anger. Anger leads to hate. Hate leads to suffering!\r\n";
      StarWarsCharacter.Taunt(Yoda.GetTauntPhrase(), Yoda);
      assertEquals(result, outContent.toString());
    }

    /**
     * Test of Fight method, of class StarWarsCharacter.
     */
    @Test
    public void testFight_TwoDifferentSidesFight_DarkWins() {
      StarWarsCharacter Darth = new StarWarsCharacter("Darth", "Vader", 42, "M", new Force(100,"Dark"), "I find your lack of faith disturbing!");
      StarWarsCharacter Yoda = new StarWarsCharacter("Yoda", "", 896, "M", new Force(99,"Light"), "Fear is the path to the dark side. Fear leads to anger. Anger leads to hate. Hate leads to suffering!");   
      String result = "Yoda fights Darth and Darth wins! Darth gloats: I find your lack of faith disturbing!\r\n";
      StarWarsCharacter.Fight(Yoda, Darth);
      assertEquals(result, outContent.toString());
    }
    
    /**
     * Test of Fight method, of class StarWarsCharacter.
     */
    @Test
    public void testFight_TwoDifferentSidesFight_LightWins() {
     StarWarsCharacter Rey = new StarWarsCharacter("Rey", "", 20, "F", new Force(96,"Light"), "Rey Skywalker!");
     StarWarsCharacter Asaji = new StarWarsCharacter("Asajj", "Ventress", 30, "F", new Force(85,"Dark"), "I don't fear you, Jedi!");
     String result = "Rey fights Asajj and Rey wins! Rey gloats: Rey Skywalker!\r\n";
     StarWarsCharacter.Fight(Rey, Asaji);
     assertEquals(result, outContent.toString());

    }
        
    /**
     * Test of Fight method, of class StarWarsCharacter.
     */
    @Test
    public void testFight_TwoDifferentSidesFight_Draws() {
     StarWarsCharacter Emperor = new StarWarsCharacter("Emperor", "Palpatine", 82, "M", new Force(97,"Dark"), "Power! Unlimited Power!");
     StarWarsCharacter Luke = new StarWarsCharacter("Luke", "Skywalker", 19, "M", new Force(97,"Light"), "You want the impossible!");
     String result = "Emperor and Luke have same strength so this match draws. \r\n";
     StarWarsCharacter.Fight(Emperor, Luke);
     assertEquals(result, outContent.toString());
    }
    
}
