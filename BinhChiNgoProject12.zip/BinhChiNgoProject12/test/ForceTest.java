import binhchingoproject12.Force;
import binhchingoproject12.StarWarsCharacter;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author binhn
 */
public class ForceTest {
    
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private final PrintStream originalErr = System.err;

    @Before
    public void setUpStreams() {
     System.setOut(new PrintStream(outContent));
     System.setErr(new PrintStream(errContent));
    }

    @After
    public void restoreStreams() {
     System.setOut(originalOut);
     System.setErr(originalErr);
    }
    
    public ForceTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    /**
     * Test of SetStrength method, of class Force.
     */
    @Test
    public void testSetStrength_DarkSideStrength_OneIntergerBetween0And100() {
      StarWarsCharacter Darth = new StarWarsCharacter("Darth", "Vader", 42, "M", new Force(100,"Dark"), "I find your lack of faith disturbing!");
      int result = 100;
      int epx = Darth.GetForce().GetStrength();
      assertEquals(result, epx);
  
    }
    
    /**
     * Test of SetStrength method, of class Force.
     */
    @Test
    public void testSetStrengthtestSetStrength_LightSideStrength_OneIntergerBetween0And100() {
      StarWarsCharacter Yoda = new StarWarsCharacter("Yoda", "", 896, "M", new Force(99,"Light"), "Fear is the path to the dark side. Fear leads to anger. Anger leads to hate. Hate leads to suffering!");   
      int result = 99;
      int epx = Yoda.GetForce().GetStrength();
      assertEquals(result, epx);
      
    }
    
    /**
     * Test of SetStrength method, of class Force.
     */
    @Test
    public void testSetStrengthtestSetStrength_StormStrength_OneIntergerBetween0And100() {
      StarWarsCharacter Storm1 = new StarWarsCharacter("Storm", "Trooper", 25, "M", new Force(1,"Dark"), "I wanna retire already!");
      int result = 1;
      int epx = Storm1.GetForce().GetStrength();
      assertEquals(result, epx);
      
    }

    /**
     * Test of Influence method, of class Force.
     */
    @Test
    public void testInfluence_DarkSideSuccessfullyInfluence_PrintedAString() {
      StarWarsCharacter Darth = new StarWarsCharacter("Darth", "Vader", 42, "M", new Force(100,"Dark"), "I find your lack of faith disturbing!");
      String result = "Darth ensures 1000 soldiers there aren't the droids they're looking for. \r\n";
      Force.Influence(Darth, "1000 soldiers");
      assertEquals(result, outContent.toString());

    }
    
       /**
     * Test of Influence method, of class Force.
     */
    @Test
    public void testInfluence_LightSideSuccessfullyInfluence_PrintedAString() {
      StarWarsCharacter Yoda = new StarWarsCharacter("Yoda", "", 896, "M", new Force(99,"Light"), "Fear is the path to the dark side. Fear leads to anger. Anger leads to hate. Hate leads to suffering!");   
      String result = "Yoda ensures 1000 soldiers there aren't the droids they're looking for. \r\n";
      Force.Influence(Yoda, "1000 soldiers");
      assertEquals(result, outContent.toString()); 

    }
    
    /**
     * Test of Influence method, of class Force.
     */
    @Test
    public void testInfluence_DarkSideFailedToInfluence_PrintedAString() {
      StarWarsCharacter Storm1 = new StarWarsCharacter("Storm", "Trooper", 25, "M", new Force(1,"Dark"), "I wanna retire already!");
      String result = "Storm fails to influence 1 soldier.\r\n";
      Force.Influence(Storm1, "1 soldier");
      assertEquals(result, outContent.toString()); 
      
    }

    /**
     * Test of Move method, of class Force.
     */
    @Test
    public void testMove_DarkSideSuccessfullyMove_PrintedAString() {
      StarWarsCharacter Darth = new StarWarsCharacter("Darth", "Vader", 42, "M", new Force(100,"Dark"), "I find your lack of faith disturbing!");
      String result = "Darth flings 1000 soldiers across the room! \r\n";
      Force.Move(Darth, "1000 soldiers");
      assertEquals(result, outContent.toString()); 
      
    }
    
    /**
     * Test of Move method, of class Force.
     */
    @Test
    public void testMove_LightSideSuccessfullyMove_PrintedAString() {
      StarWarsCharacter Yoda = new StarWarsCharacter("Yoda", "", 896, "M", new Force(99,"Light"), "Fear is the path to the dark side. Fear leads to anger. Anger leads to hate. Hate leads to suffering!");   
      String result = "Yoda flings 1000 soldiers across the room! \r\n";
      Force.Move(Yoda, "1000 soldiers");
      assertEquals(result, outContent.toString()); 
      
    }
    
    /**
     * Test of Move method, of class Force.
     */
    @Test
    public void testMove_DarkSideFailedToMove_PrintedAString() {
      StarWarsCharacter Storm1 = new StarWarsCharacter("Storm", "Trooper", 25, "M", new Force(1,"Dark"), "I wanna retire already!");
      String result = "1 rock is unmoved by Storm.\r\n";
      Force.Move(Storm1, "1 rock");
      assertEquals(result, outContent.toString()); 
      
    }
}
